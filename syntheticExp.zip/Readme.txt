Main file is syntheticExp.m 
Requires UGM at http://www.di.ens.fr/~mschmidt/Software/UGM_2009.zip
Requires TFOCS at http://tfocs.stanford.edu